print("I love, {{cookiecutter.favorite_occupation}}!")
