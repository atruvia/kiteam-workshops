print("Hello, {{cookiecutter.greeting_recipient}}!")
